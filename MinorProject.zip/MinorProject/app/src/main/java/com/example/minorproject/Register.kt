package com.example.minorproject

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth
class Register : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)

        val email = findViewById<EditText>(R.id.email)
        val password = findViewById<EditText>(R.id.password)
        val password2 = findViewById<EditText>(R.id.password1)
        val progress = findViewById<ProgressBar>(R.id.progress)
        val register = findViewById<Button>(R.id.register)
        val login=findViewById<TextView>(R.id.login)
        login.setOnClickListener {
            startActivity(Intent(this,Login::class.java))
            finish()
        }
        progress.visibility = View.GONE
        val auth: FirebaseAuth = FirebaseAuth.getInstance()

        register.setOnClickListener {
            Log.d("Register", "Register clicked")
            val email_value = email.text.toString().trim()
            val password_value = password.text.toString().trim()
            val password_value1 = password2.text.toString().trim()

            if (email_value.isEmpty() || password_value.isEmpty()) {
                Toast.makeText(this, "Email and Password cannot be empty", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            if (password_value1 == password_value) {
                progress.visibility = View.VISIBLE
                auth.createUserWithEmailAndPassword(email_value, password_value)
                    .addOnCompleteListener { task ->
                        progress.visibility = View.GONE
                        if (task.isSuccessful) {
                            Log.d("Register", "Success task")
                            val user = auth.currentUser
                            Toast.makeText(this, "Register Success: $user", Toast.LENGTH_LONG).show()
                            startActivity(Intent(this, Homepage::class.java))
                            finish()
                        } else {
                            val errorMessage = task.exception?.message
                            Toast.makeText(this, "Register Failure: $errorMessage", Toast.LENGTH_LONG).show()
                        }
                    }
            } else {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_LONG).show()
            }
        }
    }
}
