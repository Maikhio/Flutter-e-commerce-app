package com.example.minorproject

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.*

class Translation : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var speakButton: Button
    private lateinit var englishTextView: TextView
    private lateinit var hindiTextView: TextView
    private lateinit var languageSpinner: Spinner
    private lateinit var tts: TextToSpeech
    private val SPEECH_REQUEST_CODE = 101
    private var selectedLanguageCode = "hi"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_translation)

        speakButton = findViewById(R.id.speak_button)
        englishTextView = findViewById(R.id.english_text)
        hindiTextView = findViewById(R.id.hindi_translation)
        languageSpinner = findViewById(R.id.language_spinner)
        tts = TextToSpeech(this, this)

        setupLanguageSpinner()

        speakButton.setOnClickListener {
            displaySpeechRecognizer()
        }
    }

    private fun setupLanguageSpinner() {
        val languages = arrayOf("Hindi", "Spanish", "French", "German")
        val languageCodes = arrayOf("hi", "es", "fr", "de") // Language codes for the selected languages

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, languages)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        languageSpinner.adapter = adapter

        languageSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: android.view.View, position: Int, id: Long) {
                selectedLanguageCode = languageCodes[position] // Update the selected language code
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Do nothing
            }
        }
    }

    private fun displaySpeechRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.ENGLISH)
        }
        startActivityForResult(intent, SPEECH_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == SPEECH_REQUEST_CODE && resultCode == RESULT_OK) {
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = results?.get(0) ?: "No speech recognized"
            englishTextView.text = spokenText

            translateToSelectedLanguage(spokenText)
        }
    }

    private fun translateToSelectedLanguage(englishText: String) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(com.google.mlkit.nl.translate.TranslateLanguage.ENGLISH)
            .setTargetLanguage(selectedLanguageCode)
            .build()

        val translator = Translation.getClient(options)

        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(englishText)
                    .addOnSuccessListener { translatedText ->
                        hindiTextView.text = translatedText
                        speakTranslatedText(translatedText)
                    }
                    .addOnFailureListener { exception ->
                        Log.e("Translation", "Translation failed", exception)
                    }
            }
            .addOnFailureListener { exception ->
                Log.e("Translation", "Model download failed", exception)
            }
    }

    private fun speakTranslatedText(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale(selectedLanguageCode)
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
