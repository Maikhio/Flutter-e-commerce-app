package com.example.minorproject
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var recognizerIntent: Intent

    private lateinit var button: ImageView
    private lateinit var textView: TextView
    private val RECORD_AUDIO_REQUEST_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button = findViewById(R.id.button)
        textView = findViewById(R.id.textView)


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), RECORD_AUDIO_REQUEST_CODE)
        } else {
            initializeSpeechRecognizer()
        }

        button.setOnClickListener {
            if (isNetworkAvailable()) {
                textView.text = "Starting to listen..."
                speechRecognizer.startListening(recognizerIntent)
            } else {


                textView.text = "No internet connection. Please check your connection and try again."
            }
        }
    }

    private fun initializeSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {


            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)

            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }

        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                textView.text = "Listening..."


                Log.d("SpeechRecognizer", "onReadyForSpeech")
            }

            override fun onBeginningOfSpeech() {
                textView.text = "Recording..."


                Log.d("SpeechRecognizer", "onBeginningOfSpeech")
            }

            override fun onRmsChanged(rmsdB: Float) {
                Log.d("SpeechRecognizer", "onRmsChanged: $rmsdB")
            }

            override fun onBufferReceived(buffer: ByteArray?) {

                Log.d("SpeechRecognizer", "onBufferReceived")
            }

            override fun onEndOfSpeech() {
                textView.text = "Processing..."


                Log.d("SpeechRecognizer", "onEndOfSpeech")
            }

            override fun onError(error: Int) {
                when (error) {
                    SpeechRecognizer.ERROR_NETWORK -> {
                        textView.text = "Network error occurred. Please check your internet connection."
                    }

                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                        textView.text = "Network timeout. Please try again."
                    }
                    SpeechRecognizer.ERROR_AUDIO -> {



                        textView.text = "Audio recording error. Please try again."
                    }
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                        textView.text = "No speech input detected. Please try again."
                    }


                    SpeechRecognizer.ERROR_NO_MATCH -> {
                           textView.text = "No speech match found. Please try again."
                    }
                    else -> {
                        textView.text = "Error occurred: $error"
                    }
                }
                Log.e("SpeechRecognizer", "onError: $error")
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val recognizedText = matches?.get(0) ?: "No speech recognized"
                textView.text = recognizedText


                Log.d("SpeechRecognizer", "onResults: $recognizedText")
            }

            override fun onPartialResults(partialResults: Bundle?) {
                Log.d("SpeechRecognizer", "onPartialResults")
            }

            override fun onEvent(eventType: Int, params: Bundle?) {


                Log.d("SpeechRecognizer", "onEvent: $eventType")
            }
        })
    }

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork ?: return false


        val networkCapabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == RECORD_AUDIO_REQUEST_CODE) {


            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initializeSpeechRecognizer()
            } else {
                textView.text = "Microphone permission is required to use this feature."
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        speechRecognizer.destroy()
    }
}
