package com.example.minorproject

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Homepage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_homepage)
        val speech_to =findViewById<Button>(R.id.t_to_s)
        val translate=findViewById<Button>(R.id.trans)
        val generate=findViewById<Button>(R.id.gen_text)
        val settings=findViewById<ImageView>(R.id.settings)
        generate.setOnClickListener {
            val intent= Intent(this,GenerateText::class.java)
            startActivity(intent)
        }
        speech_to.setOnClickListener {
            val intent= Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
        settings.setOnClickListener {
            val intent= Intent(this,Settings::class.java)
            startActivity(intent)
        }
        translate.setOnClickListener {
            val intent=Intent(this,Translation::class.java)
            startActivity(intent)

        }

    }
}