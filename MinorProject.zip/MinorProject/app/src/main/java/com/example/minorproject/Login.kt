package com.example.minorproject

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth

class Login : AppCompatActivity() {
    override fun onStart() {
        super.onStart()
        val auth:FirebaseAuth=FirebaseAuth.getInstance()
        val currentUser = auth.currentUser
        if (currentUser != null) {
           startActivity(Intent(this,Homepage::class.java))
            finish()
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)

        val email=findViewById<EditText>(R.id.etUsername)
        val password=findViewById<EditText>(R.id.etPassword)
        val progress=findViewById<ProgressBar>(R.id.progresss)
        val auth:FirebaseAuth=FirebaseAuth.getInstance()
        val register=findViewById<TextView>(R.id.tvRegister)
        val login=findViewById<Button>(R.id.btnLogin)
        login.setOnClickListener {
            progress.visibility=View.VISIBLE
            val email_value=email.text.toString()
            val password_value=password.text.toString()
            auth.signInWithEmailAndPassword(email_value, password_value)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        progress.visibility=View.GONE
                        val user = auth.currentUser
                        Toast.makeText(this,"Login Success :$user",Toast.LENGTH_LONG).show()
                        startActivity(Intent(this,Homepage::class.java))
                        finish()

                    } else {
                        progress.visibility=View.GONE

                        val errorMessage = task.exception?.message
                        Toast.makeText(this,"Login Failure: $errorMessage ",Toast.LENGTH_LONG).show()
                    }
                }

        }
        register.setOnClickListener {
            startActivity(Intent(this,Register::class.java))
            finish()
        }
    }
}