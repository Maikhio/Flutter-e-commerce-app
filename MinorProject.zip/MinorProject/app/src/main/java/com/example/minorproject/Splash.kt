package com.example.minorproject

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class Splash : AppCompatActivity() {
    private lateinit var logo: ImageView
    private lateinit var appName: TextView
    private lateinit var topAnim: Animation
    private lateinit var bottomAnim: Animation


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_splash)
        logo=findViewById(R.id.logo)
        appName=findViewById(R.id.appName)
        topAnim= AnimationUtils.loadAnimation(this,R.anim.top_animation)
        bottomAnim= AnimationUtils.loadAnimation(this,R.anim.bottom_animation)
        logo.animation=topAnim
        appName.animation=bottomAnim

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this,Login::class.java) )
            finish()
        },2500)
        val controller= WindowInsetsControllerCompat(window,window.decorView)
        controller.hide(WindowInsetsCompat.Type.statusBars())
    }
}